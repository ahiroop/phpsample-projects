<html>
<head>
<title>Student Registration</title>
</head>
<body background="1.jpg">
<center> 
<table bgcolor=white border=0 width=100% height=6%>
<tr><td>
<table>
</table>
<td><table bgcolor=white border=0 width=80%>
<tr><td align=center width=30% font color=red size=5><a href=index.php  style="color:red; text-decoration:none;"><b>Home</b>  
<td align=center width=30% font color=red size=5><a href=aboutas.php    style="color:red; text-decoration:none;"><b>Aboutus</b>
        <td align=center width=30% font color=red size=5><a href=index.php   style="color:red; text-decoration:none;"><b>Register</b>
<td align=center width=30% font color=red size=5><a href=login.php    style="color:red; text-decoration:none;"><b>Login</b>
</table>
</table>
    <p><b>
        Interior design is the art and science of enhancing the interior of a building to achieve a healthier and more aesthetically pleasing environment for the people using the space. 
        An interior designer is someone who plans, researches, coordinates, and manages such projects.Interior design is a multifaceted profession that includes conceptual development, space planning, site inspections, programming, research, communicating with the stakeholders of a project, construction management, and execution of the design.
    </b></p>
</html>
